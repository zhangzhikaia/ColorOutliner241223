﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once
#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"

#include "ColorOutlinerSettings.generated.h"

struct FColorOutlinerSettingsDelegates
{
	DECLARE_MULTICAST_DELEGATE(FOnPostEditChangeProperty);
	//FOnPostEditChangeProperty& GetOnPostEditChangeProperty() {return OnPostEditChangeProperty;}
	
	static FOnPostEditChangeProperty OnPostEditChangeProperty;
};

UCLASS(config = Engine, defaultconfig)
class UColorOutlinerSettings : public UDeveloperSettings
{
public:
	GENERATED_BODY()
	
	UColorOutlinerSettings():bSimultaneouslySettingTextColor(false){}
	
	//~ Begin UDeveloperSettings interface
	//大分类, 若不存在新建分类
	virtual FName GetCategoryName() const override;
#if WITH_EDITOR
	//大类下二级分类, 一般为插件名
	virtual FText GetSectionText() const override;
	virtual FName GetSectionName() const override;
	virtual FText GetSectionDescription() const override;

	//~ End UDeveloperSettings interface
	
	/** UObject interface */
	//任何属性值修改将调用
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

#endif
	
	UPROPERTY(config, EditAnywhere, Category = "ColorOptions", DisplayName = "Simultaneously Setting Text Color",meta = (ToolTip="In order to more prominently identify the item whose color you've set, you can choose to set the color of the label text simultaneously.",ConfigRestartRequired = false))
	bool bSimultaneouslySettingTextColor = false;
};
